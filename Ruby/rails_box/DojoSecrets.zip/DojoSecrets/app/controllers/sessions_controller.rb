class SessionsController < ApplicationController
  def new
  end

  def create
  end

  def destroy
  end
  
end
