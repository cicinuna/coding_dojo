class IdeasController < ApplicationController
  def index
    # @ideas = Idea.joins(:likes).joins(:users).select("COUNT (DISTINCT(likes.id)) AS count", "ideas.id", "ideas.content", "ideas.user_id", "users.alias").group("likes.idea_id", "ideas.id", "ideas.content", "ideas.user_id", "users.alias").order('count DESC')
    @ideas = Idea.all

    # Tried doing custom sort of ideas by its likes count because
    # Couldn't figure out SQL QUERY for that
    # sorted_ideas = []
    # for i in 0..@ideas.length
    #   puts @ideas[i].likes.length
    # end
    render 'index'
  end

  def create
    idea = Idea.new(content: params[:content], user_id: current_user.id)
    if idea.save
      flash[:successes] = ["Successfully posted a bright idea!"]
      redirect_to '/bright_ideas'
    else
      flash[:errors] = idea.errors.full_messages
      redirect_to :back
    end
  end

  def destroy
    idea = Idea.find(params[:id])
    if idea.destroy
      flash[:successes] = ["Successfully deleted your idea!"]
      redirect_to '/bright_ideas'
    else
      flash[:errors] = idea.errors.full_messages
      redirect_to :back
    end
  end

  def like
    like = Like.new(user_id: current_user.id, idea_id: params[:id])
    if like.save
      flash[:successes] = ["Successfully Liked this Idea!"]
      redirect_to '/bright_ideas'
    else
      flash[:errors] = like.errors.full_messages
      redirect_to :back
    end
  end

  def show
    @idea = Idea.find(params[:id])
    @people = Like.joins(:user).select("DISTINCT(users.id)", "users.alias", "users.name").where("likes.idea_id = ?", params[:id])
    render 'show'
  end
end
