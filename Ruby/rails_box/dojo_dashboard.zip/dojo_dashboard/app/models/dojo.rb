class Dojo < ActiveRecord::Base
end
