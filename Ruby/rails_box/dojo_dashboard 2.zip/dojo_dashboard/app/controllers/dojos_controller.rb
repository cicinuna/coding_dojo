class DojosController < ApplicationController

    def index
        @dojos = Dojo.all
        render 'index'
    end

    def new
        render 'new'
    end

    def create
        Dojo.create( user_params )
        redirect_to '/dojos'
    end 

    private
        def user_params
            params.require(:dojo).permit(:branch, :street, :city, :state)
        end
end
