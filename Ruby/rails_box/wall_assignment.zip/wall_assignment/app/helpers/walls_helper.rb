module WallsHelper
end
