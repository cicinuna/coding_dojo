from __future__ import unicode_literals

from django.apps import AppConfig


class LikesNBooksConfig(AppConfig):
    name = 'likes_n_books'
