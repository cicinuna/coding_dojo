from __future__ import unicode_literals

from django.apps import AppConfig


class Assignment5Config(AppConfig):
    name = 'assignment_5'
