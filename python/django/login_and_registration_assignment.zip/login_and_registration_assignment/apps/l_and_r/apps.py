from __future__ import unicode_literals

from django.apps import AppConfig


class LAndRConfig(AppConfig):
    name = 'l_and_r'
