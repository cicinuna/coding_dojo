from django.shortcuts import render, redirect
from models import *
from django.contrib import messages
import re
import bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
PASSWORD_REGEX = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$')

# Create your views here.

def index(request):
    return render(request, 'reviews/index.html')

def register(request):
    error = False
    if len(request.POST['first_name']) < 2 or len(request.POST['first_name']) < 2:
        messages.error(request, 'First and Last names must be longer than 2 characters!')
        error = True
    if not request.POST['first_name'].isalpha() or not request.POST['last_name'].isalpha():
        messages.error(request, 'First and last must be alphabets!')
        error = True
    if not PASSWORD_REGEX.match(request.POST['password']):
        messages.error(request, 'Password must be 8 or more characters, contain at least 1 upper case and 1 number!')
        error = True
    if request.POST['password'] != request.POST['confirm_password']:
        messages.error(request, 'Passwords must match!')
        error = True
    if not EMAIL_REGEX.match(request.POST['email']):
        messages.error(request, 'Invalid Email address!')
        error = True
    if error:
        return redirect(index)

    else: 
        # print bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
        User.objects.create(first_name = request.POST['first_name'], last_name = request.POST['last_name'], alias = request.POST['alias'], email = request.POST['email'], password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()))
        # request.session['user'] = User.objects.last()
        session_user = {
            'first_name': request.POST['first_name'],
            'last_name': request.POST['last_name'],
            'alias': request.POST['alias'],
            'email': request.POST['email'],
            'id': User.objects.last().id
        }
        request.session['user'] = session_user
        print request.session['user']
        print "success register"
        return redirect(books)

def login(request):
    if request.method == 'POST':
        user = User.objects.get(email = request.POST['email'])
        if not user:
            messages.error(request, 'Invalid Login Information!')
            return redirect(index)
        else:
            if bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
                # messages.success(request, 'Successfully Logged In!')
                # request.session['user'] = user
                session_user = {
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'alias': user.alias,
                    'email': user.email,
                    'id': user.id
                }
                request.session['user'] = session_user
                # print request.session['user']
                print "success login"
                return redirect(books)
            else:
                messages.error(request, 'Invalid Login Information!')
                return redirect(index)
    return redirect(index)

def logout(request):
    if 'user' in request.session:
        request.session.pop('user')
        messages.success(request, 'Successfully Logged Out!')
    
    return redirect(index)

def books(request):
    content = {
        'first_book': Book.objects.first()
        # {'review': Review.objects.first()}
    }
    return render(request, 'reviews/books.html', content)

def add(request):
    return render(request, 'reviews/add.html', {'authors': Author.objects.all()})

def process_add(request):
    # print not Author.objects.filter(name = request.POST['name'])
    # print request.session['user']['id']
    if not Author.objects.filter(name = request.POST['name']):
        Author.objects.create(name = request.POST['name'])
        to_add_author = Author.objects.get(name = request.POST['name'])
        Book.objects.create(title = request.POST['title'], author = to_add_author)
        # print "here"
        # print Book.objects.last().id
        book = Book.objects.last()
        # print book_id
        print "here"
        user = User.objects.get(id = request.session['user']['id'])
        print user.first_name
        Review.objects.create(rating = request.POST['stars'], content = request.POST['review_content'], user = user, book = book)
        print "here now"
    else:
        to_add_author = Author.objects.get(name = request.POST['name'])
        Book.objects.create(title = request.POST['title'], author = to_add_author)
        book = Book.objects.last()
        user = User.objects.get(id = request.session['user']['id'])
        # print user.first_name
        Review.objects.create(rating = request.POST['stars'], content = request.POST['review_content'], user = user, book = book)
        
    id = Book.objects.last().id
    return redirect(book_info,id)

def process_edit(request):
    pass

def book_info(request, number):
    return redirect(books)

def user_info(request, number):
    pass