from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^login$', views.login),
    url(r'^logout$', views.logout),
    url(r'^books$', views.books),
    url(r'^books/add$', views.add),
    url(r'^process_add$', views.process_add),
    url(r'^process_edit$', views.process_edit),
    url(r'^books/(?P<number>\d+)$', views.book_info),
    url(r'^user/(?P<number>\d+)$', views.user_info),
]
