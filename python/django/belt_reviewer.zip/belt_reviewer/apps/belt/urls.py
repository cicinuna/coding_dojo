from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^login$', views.login),
    url(r'^logout$', views.logout),
    url(r'^books$', views.books),
    url(r'^books/add$', views.add),
    url(r'^process_add_existing$', views.process_add_existing),
    url(r'^process_add_brand_new$', views.process_add_brand_new),
    url(r'^process_edit$', views.process_edit),
    url(r'^proess_delete$', views.process_delete),
    url(r'^books/(?P<number>\d+)$', views.book_info),
    url(r'^user/(?P<number>\d+)$', views.user_info),
]
